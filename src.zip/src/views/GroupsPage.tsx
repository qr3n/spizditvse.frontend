'use client';

import { Title, Table, Loader, Alert, Card, Button, Group, Modal, Text, Box, Center } from '@mantine/core';
import { useDisclosure } from '@mantine/hooks';
import { useGroups, GroupRow } from '@/src/entities/group';
import { CreateGroupForm } from '@/src/features/create-group';
import { EditGroupButton } from '@/src/features/update-group';
import { DeleteGroupButton } from '@/src/features/delete-group';
import { IconAlertCircle, IconPlus, IconFolder } from '@tabler/icons-react';
import { useStaggerAnimation } from '@/src/shared/lib';

export default function GroupsPage() {
    const { data: groups, isLoading, error } = useGroups();
    const [opened, { open, close }] = useDisclosure(false);
    const listRef = useStaggerAnimation('tr');

    return (
        <Box maw={900}>
            <Group justify="space-between" mb="xl" align="flex-end">
                <Box>
                    <Title order={2} size="20px" fw={500} c="gray.7">Subscription Groups</Title>
                    <Text size="sm" c="gray.4" mt={4}>
                        {groups ? `${groups.length} group${groups.length !== 1 ? 's' : ''}` : 'Organise providers into groups'}
                    </Text>
                </Box>
                <Button
                    leftSection={<IconPlus size={15} stroke={2} />}
                    onClick={open}
                    size="sm"
                >
                    Add group
                </Button>
            </Group>

            <Modal opened={opened} onClose={close} title="Create group" size="sm">
                <CreateGroupForm onSuccess={close} />
            </Modal>

            {isLoading && (
                <Center h={200}>
                    <Loader size="sm" color="blue" />
                </Center>
            )}

            {error && (
                <Alert icon={<IconAlertCircle size={16} />} color="red" radius="md" variant="light">
                    Failed to load groups. Ensure the backend is running.
                </Alert>
            )}

            {!isLoading && !error && (
                <Card p={0} radius="lg" withBorder style={{ borderColor: 'var(--mantine-color-gray-2)', overflow: 'hidden' }}>
                    <Table highlightOnHover>
                        <Table.Thead>
                            <Table.Tr>
                                <Table.Th>Name</Table.Th>
                                <Table.Th>Created</Table.Th>
                                <Table.Th>Actions</Table.Th>
                            </Table.Tr>
                        </Table.Thead>
                        <Table.Tbody ref={listRef as any}>
                            {groups?.length === 0 ? (
                                <Table.Tr>
                                    <Table.Td colSpan={3}>
                                        <Center py={40}>
                                            <Box ta="center">
                                                <IconFolder size={32} color="var(--mantine-color-gray-3)" stroke={1} />
                                                <Text size="sm" c="gray.4" mt={8}>No groups yet</Text>
                                            </Box>
                                        </Center>
                                    </Table.Td>
                                </Table.Tr>
                            ) : (
                                groups?.map((group) => (
                                    <GroupRow
                                        key={group.id}
                                        group={group}
                                        actions={
                                            <>
                                                <EditGroupButton group={group} />
                                                <DeleteGroupButton id={group.id} />
                                            </>
                                        }
                                    />
                                ))
                            )}
                        </Table.Tbody>
                    </Table>
                </Card>
            )}
        </Box>
    );
}
