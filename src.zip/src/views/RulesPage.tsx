'use client';

import { Title, Table, Loader, Alert, Card, Button, Group, Modal, Text, Box, Center } from '@mantine/core';
import { useDisclosure } from '@mantine/hooks';
import { useRules, RuleRow } from '@/src/entities/rule';
import { CreateRuleForm } from '@/src/features/create-rule';
import { EditRuleButton } from '@/src/features/update-rule';
import { DeleteRuleButton } from '@/src/features/delete-rule';
import { IconAlertCircle, IconPlus, IconFilter } from '@tabler/icons-react';
import { useStaggerAnimation } from '@/src/shared/lib';

export default function RulesPage() {
    const { data: rules, isLoading, error } = useRules();
    const [opened, { open, close }] = useDisclosure(false);
    const listRef = useStaggerAnimation('tr');

    return (
        <Box maw={1100}>
            <Group justify="space-between" mb="xl" align="flex-end">
                <Box>
                    <Title order={2} size="20px" fw={500} c="gray.7">Filter Rules</Title>
                    <Text size="sm" c="gray.4" mt={4}>
                        {rules ? `${rules.filter(r => r.is_active).length} of ${rules.length} active` : 'Control traffic with glob, CIDR, or regex rules'}
                    </Text>
                </Box>
                <Button
                    leftSection={<IconPlus size={15} stroke={2} />}
                    onClick={open}
                    size="sm"
                >
                    Add rule
                </Button>
            </Group>

            <Modal opened={opened} onClose={close} title="Create rule" size="sm">
                <CreateRuleForm onSuccess={close} />
            </Modal>

            {isLoading && (
                <Center h={200}>
                    <Loader size="sm" color="blue" />
                </Center>
            )}

            {error && (
                <Alert icon={<IconAlertCircle size={16} />} color="red" radius="md" variant="light">
                    Failed to load rules. Ensure the backend is running.
                </Alert>
            )}

            {!isLoading && !error && (
                <Card p={0} radius="lg" withBorder style={{ borderColor: 'var(--mantine-color-gray-2)', overflow: 'hidden' }}>
                    <Table highlightOnHover>
                        <Table.Thead>
                            <Table.Tr>
                                <Table.Th>Pattern</Table.Th>
                                <Table.Th>Action</Table.Th>
                                <Table.Th>Status</Table.Th>
                                <Table.Th>Created</Table.Th>
                                <Table.Th>Actions</Table.Th>
                            </Table.Tr>
                        </Table.Thead>
                        <Table.Tbody ref={listRef as any}>
                            {rules?.length === 0 ? (
                                <Table.Tr>
                                    <Table.Td colSpan={5}>
                                        <Center py={40}>
                                            <Box ta="center">
                                                <IconFilter size={32} color="var(--mantine-color-gray-3)" stroke={1} />
                                                <Text size="sm" c="gray.4" mt={8}>No rules yet</Text>
                                            </Box>
                                        </Center>
                                    </Table.Td>
                                </Table.Tr>
                            ) : (
                                rules?.map((rule) => (
                                    <RuleRow
                                        key={rule.id}
                                        rule={rule}
                                        actions={
                                            <>
                                                <EditRuleButton rule={rule} />
                                                <DeleteRuleButton id={rule.id} />
                                            </>
                                        }
                                    />
                                ))
                            )}
                        </Table.Tbody>
                    </Table>
                </Card>
            )}
        </Box>
    );
}
