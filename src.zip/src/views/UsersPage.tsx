'use client';

import { Title, Table, Loader, Alert, Card, Button, Group, Modal, Text, Box, Center } from '@mantine/core';
import { useDisclosure } from '@mantine/hooks';
import { useUsers, UserRow } from '@/src/entities/user';
import { CreateUserForm } from '@/src/features/create-user';
import { ResetTokenButton } from '@/src/features/reset-user-token';
import { IconAlertCircle, IconPlus, IconUsers } from '@tabler/icons-react';
import { useStaggerAnimation } from '@/src/shared/lib';

export default function UsersPage() {
    const { data: users, isLoading, error } = useUsers();
    const [opened, { open, close }] = useDisclosure(false);
    const listRef = useStaggerAnimation('tr');

    return (
        <Box maw={1100}>
            <Group justify="space-between" mb="xl" align="flex-end">
                <Box>
                    <Title order={2} size="20px" fw={500} c="gray.7">Users</Title>
                    <Text size="sm" c="gray.4" mt={4}>
                        {users ? `${users.filter(u => u.is_active).length} of ${users.length} active` : 'Manage subscription users'}
                    </Text>
                </Box>
                <Button
                    leftSection={<IconPlus size={15} stroke={2} />}
                    onClick={open}
                    size="sm"
                >
                    Add user
                </Button>
            </Group>

            <Modal opened={opened} onClose={close} title="Create user" size="sm">
                <CreateUserForm onSuccess={close} />
            </Modal>

            {isLoading && (
                <Center h={200}>
                    <Loader size="sm" color="blue" />
                </Center>
            )}

            {error && (
                <Alert icon={<IconAlertCircle size={16} />} color="red" radius="md" variant="light">
                    Failed to load users. Ensure the backend is running.
                </Alert>
            )}

            {!isLoading && !error && (
                <Card p={0} radius="lg" withBorder style={{ borderColor: 'var(--mantine-color-gray-2)', overflow: 'hidden' }}>
                    <Table highlightOnHover>
                        <Table.Thead>
                            <Table.Tr>
                                <Table.Th>Name</Table.Th>
                                <Table.Th>Status</Table.Th>
                                <Table.Th>Expires</Table.Th>
                                <Table.Th>Sub link</Table.Th>
                                <Table.Th>Actions</Table.Th>
                            </Table.Tr>
                        </Table.Thead>
                        <Table.Tbody ref={listRef as any}>
                            {users?.length === 0 ? (
                                <Table.Tr>
                                    <Table.Td colSpan={5}>
                                        <Center py={40}>
                                            <Box ta="center">
                                                <IconUsers size={32} color="var(--mantine-color-gray-3)" stroke={1} />
                                                <Text size="sm" c="gray.4" mt={8}>No users yet</Text>
                                            </Box>
                                        </Center>
                                    </Table.Td>
                                </Table.Tr>
                            ) : (
                                users?.map((user) => (
                                    <UserRow
                                        key={user.id}
                                        user={user}
                                        actions={<ResetTokenButton userId={user.id} />}
                                    />
                                ))
                            )}
                        </Table.Tbody>
                    </Table>
                </Card>
            )}
        </Box>
    );
}
