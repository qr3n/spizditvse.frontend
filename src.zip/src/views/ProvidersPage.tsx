'use client';

import { useMemo } from 'react';
import { Title, SimpleGrid, Loader, Alert, Button, Group, Modal, Card, Text, ActionIcon, Box, Center, Badge } from '@mantine/core';
import { useDisclosure } from '@mantine/hooks';
import { useProviders, ProviderCard } from '@/src/entities/provider';
import { useGroups } from '@/src/entities/group';
import { CreateProviderForm } from '@/src/features/create-provider';
import { RefreshProviderButton } from '@/src/features/refresh-provider';
import { EditProviderButton } from '@/src/features/update-provider';
import { DeleteProviderButton } from '@/src/features/delete-provider';
import { IconAlertCircle, IconPlus, IconArrowLeft, IconFolder, IconServer } from '@tabler/icons-react';
import { useRouter } from 'next/navigation';
import { useStaggerAnimation } from '@/src/shared/lib';

interface ProvidersPageProps {
    groupId?: string | null;
}

export default function ProvidersPage({ groupId }: ProvidersPageProps) {
    const { data: providers, isLoading: providersLoading, error: providersError } = useProviders();
    const { data: groups, isLoading: groupsLoading, error: groupsError } = useGroups();
    const [opened, { open, close }] = useDisclosure(false);
    const router = useRouter();
    const groupsListRef = useStaggerAnimation('> *');
    const providersListRef = useStaggerAnimation('> *');

    const isLoading = providersLoading || groupsLoading;
    const error = providersError || groupsError;

    const groupStats = useMemo(() => {
        if (!providers) return { ungrouped: 0, byGroup: {} as Record<string, number> };
        const stats = { ungrouped: 0, byGroup: {} as Record<string, number> };
        providers.forEach(p => {
            if (p.group_id) {
                stats.byGroup[p.group_id] = (stats.byGroup[p.group_id] || 0) + 1;
            } else {
                stats.ungrouped++;
            }
        });
        return stats;
    }, [providers]);

    const filteredProviders = useMemo(() => {
        if (!providers || groupId === undefined) return [];
        return providers.filter(p => p.group_id === groupId);
    }, [providers, groupId]);

    const currentGroupName = useMemo(() => {
        if (groupId === undefined) return '';
        if (groupId === null) return 'Ungrouped';
        return groups?.find(g => g.id === groupId)?.name || 'Unknown Group';
    }, [groups, groupId]);

    if (isLoading) return (
        <Center h={200}>
            <Loader size="sm" color="blue" />
        </Center>
    );

    if (error) return (
        <Alert icon={<IconAlertCircle size={16} />} color="red" radius="md" variant="light">
            Failed to load data. Ensure the backend is running.
        </Alert>
    );

    return (
        <Box maw={1100}>
            <Group justify="space-between" mb="xl" align="flex-end">
                <Group gap="xs" align="center">
                    {groupId !== undefined && (
                        <ActionIcon
                            variant="subtle"
                            color="gray"
                            onClick={() => router.push('/providers')}
                            radius="md"
                        >
                            <IconArrowLeft size={18} stroke={1.5} />
                        </ActionIcon>
                    )}
                    <Box>
                        <Title order={2} size="20px" fw={500} c="gray.7">
                            {groupId === undefined ? 'Providers' : currentGroupName}
                        </Title>
                        <Text size="sm" c="gray.4" mt={4}>
                            {groupId === undefined
                                ? `${groups?.length || 0} groups · ${providers?.length || 0} providers total`
                                : `${filteredProviders.length} provider${filteredProviders.length !== 1 ? 's' : ''}`
                            }
                        </Text>
                    </Box>
                </Group>
                <Button
                    leftSection={<IconPlus size={15} stroke={2} />}
                    onClick={open}
                    size="sm"
                >
                    Add provider
                </Button>
            </Group>

            <Modal opened={opened} onClose={close} title="Add provider" size="sm">
                <CreateProviderForm onSuccess={close} />
            </Modal>

            {groupId === undefined ? (
                // Groups view
                <SimpleGrid cols={{ base: 1, sm: 2, lg: 3 }} spacing="md" ref={groupsListRef as any}>
                    {groups?.map(group => (
                        <Card
                            key={group.id}
                            p="lg"
                            radius="lg"
                            withBorder
                            style={{
                                cursor: 'pointer',
                                borderColor: 'var(--mantine-color-gray-2)',
                                transition: 'border-color 0.15s ease, background-color 0.15s ease',
                            }}
                            onClick={() => router.push(`/providers/${group.id}`)}
                        >
                            <Group justify="space-between" align="center">
                                <Group gap="sm">
                                    <Box
                                        style={{
                                            width: 36,
                                            height: 36,
                                            borderRadius: 8,
                                            backgroundColor: 'var(--mantine-color-blue-0)',
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                            flexShrink: 0,
                                        }}
                                    >
                                        <IconFolder size={18} color="var(--mantine-color-blue-5)" stroke={1.5} />
                                    </Box>
                                    <Box>
                                        <Text fw={500} size="sm" c="gray.7">{group.name}</Text>
                                        <Text size="12px" c="gray.4">
                                            {groupStats.byGroup[group.id] || 0} providers
                                        </Text>
                                    </Box>
                                </Group>
                                <Badge variant="light" color="gray" size="sm">
                                    {groupStats.byGroup[group.id] || 0}
                                </Badge>
                            </Group>
                        </Card>
                    ))}

                    {/* Ungrouped */}
                    <Card
                        p="lg"
                        radius="lg"
                        withBorder
                        style={{
                            cursor: 'pointer',
                            borderColor: 'var(--mantine-color-gray-2)',
                            borderStyle: 'dashed',
                            transition: 'border-color 0.15s ease',
                        }}
                        onClick={() => router.push('/providers/ungrouped')}
                    >
                        <Group justify="space-between" align="center">
                            <Group gap="sm">
                                <Box
                                    style={{
                                        width: 36,
                                        height: 36,
                                        borderRadius: 8,
                                        backgroundColor: 'var(--mantine-color-gray-1)',
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        flexShrink: 0,
                                    }}
                                >
                                    <IconServer size={18} color="var(--mantine-color-gray-5)" stroke={1.5} />
                                </Box>
                                <Box>
                                    <Text fw={500} size="sm" c="gray.6">Ungrouped</Text>
                                    <Text size="12px" c="gray.4">{groupStats.ungrouped} providers</Text>
                                </Box>
                            </Group>
                            <Badge variant="light" color="gray" size="sm">
                                {groupStats.ungrouped}
                            </Badge>
                        </Group>
                    </Card>
                </SimpleGrid>
            ) : (
                // Providers list
                filteredProviders.length === 0 ? (
                    <Center h={200}>
                        <Box ta="center">
                            <IconServer size={36} color="var(--mantine-color-gray-3)" stroke={1} />
                            <Text size="sm" c="gray.4" mt={8}>No providers in this group</Text>
                        </Box>
                    </Center>
                ) : (
                    <SimpleGrid cols={{ base: 1, sm: 2, lg: 3 }} spacing="md" ref={providersListRef as any}>
                        {filteredProviders.map((provider) => (
                            <ProviderCard
                                key={provider.id}
                                provider={provider}
                                actions={
                                    <>
                                        <RefreshProviderButton subId={provider.id} />
                                        <EditProviderButton provider={provider} />
                                        <DeleteProviderButton id={provider.id} />
                                    </>
                                }
                            />
                        ))}
                    </SimpleGrid>
                )
            )}
        </Box>
    );
}
