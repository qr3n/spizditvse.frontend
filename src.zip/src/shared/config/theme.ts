import { createTheme } from '@mantine/core';

// Google / Material Design 3 inspired palette
// Primary: Google Blue #1A73E8
// Surface: #F8FAFD (very light blue-gray)
// Card: #FFFFFF
// Border: #E0E3E8 (subtle, not overwhelming)
// Text: #202124 / #5F6368

export const theme = createTheme({
  primaryColor: 'blue',
  fontFamily: '"Google Sans", "Inter", system-ui, -apple-system, sans-serif',
  headings: {
    fontFamily: '"Google Sans", "Inter", system-ui, -apple-system, sans-serif',
    fontWeight: '500',
  },
  defaultRadius: 'md',
  colors: {
    // Mantine needs 10 shades; we override blue to match Google Blue
    blue: [
      '#E8F0FE', // 0 - very light blue (chip/badge bg)
      '#D2E3FC', // 1
      '#AECBFA', // 2
      '#7BAAF7', // 3
      '#4285F4', // 4
      '#1A73E8', // 5 - Google Blue primary
      '#1557B0', // 6
      '#0D47A1', // 7
      '#083A8A', // 8
      '#042E72', // 9
    ],
    gray: [
      '#F8FAFD', // 0 - page background
      '#F1F3F4', // 1 - sidebar/hover
      '#E0E3E8', // 2 - borders
      '#BDC1C6', // 3 - disabled
      '#9AA0A6', // 4 - placeholder
      '#5F6368', // 5 - secondary text
      '#3C4043', // 6 - body text
      '#202124', // 7 - headings/primary text
      '#17181A', // 8
      '#0D0E0F', // 9
    ],
  },
  shadows: {
    xs: '0 1px 2px rgba(60,64,67,0.08)',
    sm: '0 1px 3px rgba(60,64,67,0.12)',
    md: '0 2px 6px rgba(60,64,67,0.1)',
    lg: '0 4px 12px rgba(60,64,67,0.1)',
    xl: '0 8px 24px rgba(60,64,67,0.12)',
  },
  components: {
    Card: {
      defaultProps: {
        shadow: undefined,
        radius: 'lg',
        withBorder: true,
      },
      styles: {
        root: {
          borderColor: 'var(--mantine-color-gray-2)',
          backgroundColor: '#fff',
          transition: 'border-color 0.15s ease',
          '&:hover': {
            borderColor: 'var(--mantine-color-gray-3)',
          }
        }
      }
    },
    Button: {
      defaultProps: {
        radius: 'xl',
        fw: 500,
      },
      styles: {
        root: {
          letterSpacing: '0.01em',
          transition: 'background-color 0.15s ease, box-shadow 0.15s ease',
          '&:not([data-variant="subtle"]):not([data-variant="transparent"])': {
            boxShadow: '0 1px 2px rgba(26,115,232,0.2)',
          },
          '&:hover:not([data-variant="subtle"]):not([data-variant="transparent"])': {
            boxShadow: '0 2px 6px rgba(26,115,232,0.3)',
          },
          '&:active': {
            transform: 'scale(0.99)',
          }
        }
      }
    },
    Badge: {
      defaultProps: {
        variant: 'light',
        radius: 'sm',
        fw: 500,
      },
      styles: {
        root: {
          textTransform: 'none',
          letterSpacing: '0',
          fontSize: '12px',
          padding: '2px 8px',
        }
      }
    },
    Table: {
      styles: {
        table: {
          borderCollapse: 'collapse',
        },
        th: {
          borderBottom: '1px solid var(--mantine-color-gray-2)',
          color: 'var(--mantine-color-gray-5)',
          fontSize: '11px',
          textTransform: 'uppercase',
          letterSpacing: '0.8px',
          fontWeight: 600,
          padding: '12px 16px',
        },
        td: {
          borderBottom: '1px solid var(--mantine-color-gray-1)',
          padding: '14px 16px',
          color: 'var(--mantine-color-gray-7)',
        },
        tr: {
          transition: 'background-color 0.1s ease',
        }
      }
    },
    NavLink: {
      styles: {
        root: {
          borderRadius: '0 24px 24px 0',
          marginBottom: '2px',
          transition: 'background-color 0.1s ease',
          padding: '8px 24px 8px 16px',
          color: 'var(--mantine-color-gray-6)',
          '&:hover': {
            backgroundColor: 'var(--mantine-color-gray-1)',
            color: 'var(--mantine-color-gray-7)',
          },
          '&[data-active]': {
            backgroundColor: 'var(--mantine-color-blue-0)',
            color: 'var(--mantine-color-blue-5)',
          },
          '&[data-active]:hover': {
            backgroundColor: 'var(--mantine-color-blue-1)',
          }
        },
        label: {
          fontWeight: 500,
          fontSize: '14px',
        },
        icon: {
          marginRight: '12px',
          color: 'inherit',
        }
      }
    },
    TextInput: {
      styles: {
        label: {
          fontSize: '13px',
          fontWeight: 500,
          color: 'var(--mantine-color-gray-6)',
          marginBottom: '6px',
        },
        input: {
          borderColor: 'var(--mantine-color-gray-2)',
          '&:focus': {
            borderColor: 'var(--mantine-color-blue-5)',
          }
        }
      }
    },
    Select: {
      styles: {
        label: {
          fontSize: '13px',
          fontWeight: 500,
          color: 'var(--mantine-color-gray-6)',
          marginBottom: '6px',
        },
        input: {
          borderColor: 'var(--mantine-color-gray-2)',
          '&:focus': {
            borderColor: 'var(--mantine-color-blue-5)',
          }
        }
      }
    },
    Modal: {
      styles: {
        title: {
          fontWeight: 500,
          fontSize: '16px',
          color: 'var(--mantine-color-gray-7)',
        },
        header: {
          borderBottom: '1px solid var(--mantine-color-gray-2)',
          paddingBottom: '12px',
          marginBottom: '4px',
        }
      }
    },
    Paper: {
      defaultProps: {
        radius: 'lg',
      }
    },
    ActionIcon: {
      defaultProps: {
        radius: 'md',
      },
      styles: {
        root: {
          transition: 'background-color 0.1s ease',
        }
      }
    }
  },
});
