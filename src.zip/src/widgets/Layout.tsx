'use client';

import { AppShell, Burger, Group, NavLink, Text, Box, Divider } from '@mantine/core';
import { useDisclosure } from '@mantine/hooks';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { LogoutButton } from '@/src/features/auth';
import { PageTransition } from '@/src/shared/ui';
import {
    IconLayoutDashboard,
    IconServer,
    IconUsers,
    IconFolder,
    IconFilter,
    IconShield
} from '@tabler/icons-react';

const links = [
    { label: 'Dashboard', href: '/', icon: IconLayoutDashboard },
    { label: 'Providers', href: '/providers', icon: IconServer },
    { label: 'Users', href: '/users', icon: IconUsers },
    { label: 'Groups', href: '/groups', icon: IconFolder },
    { label: 'Rules', href: '/rules', icon: IconFilter },
];

export function Layout({ children }: { children: React.ReactNode }) {
    const [opened, { toggle }] = useDisclosure();
    const pathname = usePathname();

    return (
        <AppShell
            header={{ height: 56 }}
            navbar={{
                width: 240,
                breakpoint: 'sm',
                collapsed: { mobile: !opened },
            }}
            padding="lg"
            styles={{
                header: {
                    backgroundColor: '#fff',
                    borderBottom: '1px solid var(--mantine-color-gray-2)',
                    boxShadow: 'none',
                },
                navbar: {
                    backgroundColor: '#fff',
                    borderRight: '1px solid var(--mantine-color-gray-2)',
                    paddingTop: '8px',
                    paddingLeft: '0',
                    paddingRight: '0',
                },
                main: {
                    backgroundColor: 'var(--mantine-color-gray-0)',
                    minHeight: '100vh',
                },
            }}
        >
            <AppShell.Header>
                <Group h="100%" px="md" gap="sm" justify="space-between">
                    <Group gap="sm">
                        <Burger opened={opened} onClick={toggle} hiddenFrom="sm" size="sm" />
                        <Group gap="xs" align="center">
                            <Box
                                style={{
                                    width: 28,
                                    height: 28,
                                    borderRadius: 8,
                                    backgroundColor: 'var(--mantine-color-blue-5)',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    flexShrink: 0,
                                }}
                            >
                                <IconShield size={16} color="#fff" stroke={2} />
                            </Box>
                            <Text
                                size="sm"
                                fw={600}
                                c="gray.7"
                                style={{ letterSpacing: '-0.01em' }}
                            >
                                VPN Admin
                            </Text>
                        </Group>
                    </Group>
                    <LogoutButton />
                </Group>
            </AppShell.Header>

            <AppShell.Navbar pt="xs" pb="md">
                <Box px="md" mb="xs">
                    <Text size="10px" fw={700} c="gray.4" tt="uppercase" style={{ letterSpacing: '1px' }}>
                        Navigation
                    </Text>
                </Box>
                {links.map((link) => {
                    const Icon = link.icon;
                    const isActive = link.href === '/'
                        ? pathname === '/'
                        : pathname.startsWith(link.href);
                    return (
                        <NavLink
                            key={link.href}
                            component={Link}
                            href={link.href}
                            label={link.label}
                            leftSection={<Icon size={18} stroke={isActive ? 2 : 1.5} />}
                            active={isActive}
                        />
                    );
                })}
            </AppShell.Navbar>

            <AppShell.Main>
                <PageTransition>
                    {children}
                </PageTransition>
            </AppShell.Main>
        </AppShell>
    );
}
