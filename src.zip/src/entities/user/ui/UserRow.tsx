import { Table, Badge, ActionIcon, Group, Tooltip, CopyButton, Text, Box } from '@mantine/core';
import { IconCopy, IconCheck } from '@tabler/icons-react';
import { User } from '../types';

interface UserRowProps {
    user: User;
    actions?: React.ReactNode;
}

function isExpired(date: string) {
    return new Date(date) < new Date();
}

export function UserRow({ user, actions }: UserRowProps) {
    return (
        <Table.Tr>
            <Table.Td>
                <Text size="sm" fw={500} c="gray.7">{user.name}</Text>
            </Table.Td>
            <Table.Td>
                <Badge
                    color={user.is_active ? 'teal' : 'gray'}
                    variant="light"
                    size="sm"
                >
                    {user.is_active ? 'Active' : 'Inactive'}
                </Badge>
            </Table.Td>
            <Table.Td>
                {user.subscription_expires_at ? (
                    <Text size="sm" c={isExpired(user.subscription_expires_at) ? 'red' : 'gray.6'}>
                        {new Date(user.subscription_expires_at).toLocaleDateString('en-GB', {
                            day: '2-digit', month: 'short', year: 'numeric'
                        })}
                    </Text>
                ) : (
                    <Text size="sm" c="gray.4">—</Text>
                )}
            </Table.Td>
            <Table.Td>
                <CopyButton value={user.sub_url} timeout={2000}>
                    {({ copied, copy }) => (
                        <Tooltip label={copied ? 'Copied!' : 'Copy subscription URL'} withArrow position="top">
                            <ActionIcon
                                color={copied ? 'teal' : 'gray'}
                                variant="subtle"
                                size="sm"
                                onClick={copy}
                            >
                                {copied ? <IconCheck size={14} /> : <IconCopy size={14} />}
                            </ActionIcon>
                        </Tooltip>
                    )}
                </CopyButton>
            </Table.Td>
            <Table.Td>
                <Group gap={4}>
                    {actions}
                </Group>
            </Table.Td>
        </Table.Tr>
    );
}
