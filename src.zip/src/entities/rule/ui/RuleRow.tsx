import { Table, Group, Badge, Text } from '@mantine/core';
import { FilterRule } from '../types';

interface RuleRowProps {
    rule: FilterRule;
    actions?: React.ReactNode;
}

export function RuleRow({ rule, actions }: RuleRowProps) {
    return (
        <Table.Tr>
            <Table.Td>
                <Text size="sm" fw={500} c="gray.7" ff="monospace" style={{ fontSize: '13px' }}>
                    {rule.pattern}
                </Text>
                {rule.description && (
                    <Text size="12px" c="gray.4" mt={2}>{rule.description}</Text>
                )}
            </Table.Td>
            <Table.Td>
                <Badge
                    color={rule.action === 'block' ? 'red' : 'teal'}
                    variant="light"
                    size="sm"
                >
                    {rule.action}
                </Badge>
            </Table.Td>
            <Table.Td>
                <Badge
                    color={rule.is_active ? 'teal' : 'gray'}
                    variant="light"
                    size="sm"
                >
                    {rule.is_active ? 'Active' : 'Inactive'}
                </Badge>
            </Table.Td>
            <Table.Td>
                <Text size="12px" c="gray.4">
                    {new Date(rule.created_at).toLocaleDateString('en-GB', {
                        day: '2-digit', month: 'short', year: 'numeric'
                    })}
                </Text>
            </Table.Td>
            <Table.Td>
                <Group gap={4}>
                    {actions}
                </Group>
            </Table.Td>
        </Table.Tr>
    );
}
