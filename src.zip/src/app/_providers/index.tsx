'use client';

import { MantineProvider } from '@mantine/core';
import { ReactQueryProvider } from './ReactQueryProvider';
import { theme } from '@/src/shared/config/theme';
import { Toaster } from 'react-hot-toast';

export function AppProvider({ children }: { children: React.ReactNode }) {
    return (
        <ReactQueryProvider>
            <MantineProvider theme={theme} forceColorScheme="light">
                <Toaster
                    position="top-right"
                    reverseOrder={false}
                    toastOptions={{
                        style: {
                            borderRadius: '10px',
                            border: '1px solid #E0E3E8',
                            boxShadow: '0 4px 12px rgba(60,64,67,0.1)',
                            fontFamily: '"Google Sans", "Inter", sans-serif',
                            fontSize: '14px',
                            color: '#3C4043',
                        },
                        success: {
                            iconTheme: { primary: '#1A73E8', secondary: '#fff' },
                        },
                    }}
                />
                {children}
            </MantineProvider>
        </ReactQueryProvider>
    );
}
