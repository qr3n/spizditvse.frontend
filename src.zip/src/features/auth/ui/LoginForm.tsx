'use client';

import { TextInput, Button, Paper, Title, Text, Box, Stack } from '@mantine/core';
import { useForm } from '@mantine/form';
import { useRouter } from 'next/navigation';
import { setToken } from '@/src/shared/lib/token';
import toast from 'react-hot-toast';
import { IconShield } from '@tabler/icons-react';

export function LoginForm() {
    const router = useRouter();

    const form = useForm({
        initialValues: { token: '' },
        validate: {
            token: (value) => (value.trim().length > 0 ? null : 'Token is required'),
        },
    });

    const handleSubmit = (values: typeof form.values) => {
        setToken(values.token);
        toast.success('Signed in');
        router.push('/');
    };

    return (
        <Box
            style={{
                minHeight: '100vh',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                backgroundColor: 'var(--mantine-color-gray-0)',
            }}
        >
            <Box w={400} px="md">
                {/* Logo */}
                <Box ta="center" mb="xl">
                    <Box
                        style={{
                            width: 48,
                            height: 48,
                            borderRadius: 14,
                            backgroundColor: 'var(--mantine-color-blue-5)',
                            display: 'inline-flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            marginBottom: 16,
                        }}
                    >
                        <IconShield size={24} color="#fff" stroke={1.5} />
                    </Box>
                    <Title order={2} size="22px" fw={500} c="gray.7">VPN Admin</Title>
                    <Text size="sm" c="gray.4" mt={4}>Enter your admin token to continue</Text>
                </Box>

                <Paper
                    shadow={undefined}
                    p="xl"
                    radius="xl"
                    withBorder
                    style={{ borderColor: 'var(--mantine-color-gray-2)' }}
                >
                    <form onSubmit={form.onSubmit(handleSubmit)}>
                        <Stack gap="md">
                            <TextInput
                                label="Admin token"
                                placeholder="Bearer token"
                                size="md"
                                radius="md"
                                type="password"
                                {...form.getInputProps('token')}
                            />
                            <Button fullWidth type="submit" size="md" mt={4}>
                                Sign in
                            </Button>
                        </Stack>
                    </form>
                </Paper>
            </Box>
        </Box>
    );
}
