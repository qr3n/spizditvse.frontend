'use client';

import { ActionIcon, Tooltip } from '@mantine/core';
import { IconTrash } from '@tabler/icons-react';
import { useDeleteRule } from '../api';

export function DeleteRuleButton({ id }: { id: string }) {
    const { mutate, isPending } = useDeleteRule();

    const handleDelete = () => {
        if (confirm('Delete this rule?')) {
            mutate(id);
        }
    };

    return (
        <Tooltip label="Delete" withArrow position="top">
            <ActionIcon
                color="gray"
                variant="subtle"
                size="sm"
                radius="md"
                onClick={handleDelete}
                loading={isPending}
            >
                <IconTrash size={14} stroke={1.5} />
            </ActionIcon>
        </Tooltip>
    );
}
