'use client';

import { ActionIcon, Tooltip } from '@mantine/core';
import { IconRefresh } from '@tabler/icons-react';
import { useRefreshProvider } from './api';

export function RefreshProviderButton({ subId }: { subId: string }) {
    const { mutate, isPending } = useRefreshProvider();

    return (
        <Tooltip label="Refresh" withArrow position="top">
            <ActionIcon
                color="gray"
                variant="subtle"
                size="sm"
                radius="md"
                onClick={() => mutate(subId)}
                loading={isPending}
            >
                <IconRefresh size={14} stroke={1.5} />
            </ActionIcon>
        </Tooltip>
    );
}
