'use client';

import { ActionIcon, Tooltip } from '@mantine/core';
import { IconTrash } from '@tabler/icons-react';
import { useDeleteGroup } from '../api';

export function DeleteGroupButton({ id }: { id: string }) {
    const { mutate, isPending } = useDeleteGroup();

    const handleDelete = () => {
        if (confirm('Delete this group? Providers will be detached.')) {
            mutate(id);
        }
    };

    return (
        <Tooltip label="Delete" withArrow position="top">
            <ActionIcon
                color="gray"
                variant="subtle"
                size="sm"
                radius="md"
                onClick={handleDelete}
                loading={isPending}
            >
                <IconTrash size={14} stroke={1.5} />
            </ActionIcon>
        </Tooltip>
    );
}
