'use client';

import { ActionIcon, Tooltip } from '@mantine/core';
import { IconEdit } from '@tabler/icons-react';
import { useDisclosure } from '@mantine/hooks';
import { EditProviderModal } from './EditProviderModal';
import { Provider } from '@/src/entities/provider';

export function EditProviderButton({ provider }: { provider: Provider }) {
    const [opened, { open, close }] = useDisclosure(false);

    return (
        <>
            <Tooltip label="Edit" withArrow position="top">
                <ActionIcon
                    color="gray"
                    variant="subtle"
                    size="sm"
                    radius="md"
                    onClick={open}
                >
                    <IconEdit size={14} stroke={1.5} />
                </ActionIcon>
            </Tooltip>
            <EditProviderModal provider={provider} opened={opened} onClose={close} />
        </>
    );
}
