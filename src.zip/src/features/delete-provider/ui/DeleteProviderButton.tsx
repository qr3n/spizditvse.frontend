'use client';

import { ActionIcon, Tooltip } from '@mantine/core';
import { IconTrash } from '@tabler/icons-react';
import { useDeleteProvider } from '../api';

export function DeleteProviderButton({ id }: { id: string }) {
    const { mutate, isPending } = useDeleteProvider();

    const handleDelete = () => {
        if (confirm('Delete this provider?')) {
            mutate(id);
        }
    };

    return (
        <Tooltip label="Delete" withArrow position="top">
            <ActionIcon
                color="gray"
                variant="subtle"
                size="sm"
                radius="md"
                onClick={handleDelete}
                loading={isPending}
            >
                <IconTrash size={14} stroke={1.5} />
            </ActionIcon>
        </Tooltip>
    );
}
